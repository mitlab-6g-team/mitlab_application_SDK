from AppAuthN.checkAuthN import is_validate_input

device_id = "device_1"
application_token = "d8f1f3cd-dc21-430c-9270-3c25354b4672"
position_id = "d8f1f3cd-dc21-430c-9270-3c25354b4672"

is_validate_input(device_id, application_token, position_id)
